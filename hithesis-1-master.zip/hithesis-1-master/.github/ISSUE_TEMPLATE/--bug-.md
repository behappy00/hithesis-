---
name: '发现BUG:'
about: hithesis中哪个校区哪个学位具体哪一个模板
title: ''
labels: bug
assignees: dustincys

---

**描述bug类型**

- 校区（哈尔滨/威海/深圳？）：

- 学位（本/硕/博？）：

- 论文类型（毕业论文/开题/中期/博后/English Version？）：

- 证据（与规范不符/与word模板不符？）：

- 证据所在网页（窝工规范或者word模板所在窝工官方网页）：

**描述bug具体信息** 

窝工在（规范/word模板中）第（xxx）行规定格式为：

如图：

hithesis的格式为


如图：

如码：
